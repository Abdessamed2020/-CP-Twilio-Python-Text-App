account_sid = "Your Account Sid"
auth_token = "Your Auth Token"
my_cell = "+Your Cell Number"
my_twilio = "+Your Twilio Number"